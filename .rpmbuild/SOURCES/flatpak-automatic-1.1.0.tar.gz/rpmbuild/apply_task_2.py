# apply_task_2.py
import os
import re

print("📝 Updating Makefile and CHANGELOG.md for version 1.1.0...")

version = "1.1.0"
date_str = "2026-04-22"

# 1. Update Makefile Version
makefile_path = 'Makefile'
if os.path.exists(makefile_path):
    with open(makefile_path, 'r') as f:
        makefile_content = f.read()
    
    # Replace any existing VERSION assignment with 1.1.0
    makefile_content = re.sub(
        r'^VERSION := \d+\.\d+\.\d+.*$', 
        f'VERSION := {version}', 
        makefile_content, 
        flags=re.MULTILINE
    )
    
    with open(makefile_path, 'w') as f:
        f.write(makefile_content)
    print(f"✅ Updated {makefile_path} to version {version}")

# 2. Update CHANGELOG.md
changelog_path = 'CHANGELOG.md'
if os.path.exists(changelog_path):
    with open(changelog_path, 'r') as f:
        changelog_content = f.read()
    
    new_changelog_entry = f"""## [{version}] - {date_str}

### Fixed

- **Packaging**: Expanded 'pre' to 'pre-update' in the spec description to resolve rpmlint spelling warnings.
- **Packaging**: Suppressed rpmlint warnings for missing man pages, `incoherent-version-in-changelog`, and empty `%preun` scriptlets.

"""
    
    # Check if the version is already there to ensure idempotency
    if f"## [{version}]" not in changelog_content:
        # Insert the new entry right before the first existing release header
        changelog_content = re.sub(
            r'(## \[\d+\.\d+\.\d+.*\] - \d{4}-\d{2}-\d{2})',
            f'{new_changelog_entry}\\1',
            changelog_content,
            count=1
        )
        
        with open(changelog_path, 'w') as f:
            f.write(changelog_content)
        print(f"✅ Added version {version} to {changelog_path}")
    else:
        print(f"⚠️ Version {version} already exists in {changelog_path}")

print("✅ Successfully generated Task 2 updates!")